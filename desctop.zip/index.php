<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=1200">
        <title>МАГИЯ ДЕКОРА</title>
        <link type="image/x-icon" href="favicon.ico" rel="shortcut icon">
        <script>
            if (screen.width <= 750) {
                document.location = "../mobile/" + document.location.search;
            }
        </script>
        <style>
            <?php include('css/head.css');
            ?>
        </style>
        <link type="text/css" href="css/libs.css" rel="stylesheet">
        <link type="text/css" href="css/style.css" rel="stylesheet">
        <link type="text/css" href="css/media.css" rel="stylesheet">
        <link type="text/css" href="css/scripts.css" rel="stylesheet">
        <?php include('../track/head.php'); ?>
    </head>
    <body>
        <div id="loader-wrap">
            <div class="loader">
                <div class="square square--main">
                    <div class="square square--mini"></div>
                    <div class="square square--mini"></div>
                    <div class="square square--mini"></div>
                    <div class="square square--mini"></div>
                    <div class="square square--mini"></div>
                    <div class="square square--mini"></div>
                    <div class="square square--mini"></div>
                    <div class="square square--mini"></div>
                    <div class="square square--mini"></div>
                    <div class="square square--mini"></div>
                    <div class="square square--mini"></div>
                    <div class="square square--mini"></div>
                    <div class="square square--mini"></div>
                    <div class="square square--mini"></div>
                    <div class="square square--mini"></div>
                    <div class="square square--mini"></div>
                </div>
            </div>
        </div>
        <header id="m-sect1">
            <div class="wrap">
                <div class="head">
                    <span class="logo">магия декора</span>
                    <div class="fone">
                        <span>8 800 000 99 44</span>
                        <a class="zz-btn" href="#">Заказать звонок</a>
                    </div>
                    <p>Интерьер мечты</p>
                </div>
                <h2>За 3 дня создадим уютную атмосферу за счет <br>индивидуального оформления штор и <br>дополнений под ключ</h2>
                <p class="podt">14 лет на рынке. <br>Собственное производство.</p>
            </div>
        </header>
        <section class="sec2" id="m-sect2">
            <div class="wrap">
                <h2>Мы всегда находим идеальное решение</h2>
                <ul class="liner">
                    <li>
                        <a data-slide="1" href="#">Для квартир</a>
                    </li>
                    <li>
                        <a data-slide="2" href="#">Для домов</a>
                    </li>
                    <li>
                        <a data-slide="3" href="#">Для организаций</a>
                    </li>
                    <li>
                        <a data-slide="4" href="#">Для мероприятий</a>
                    </li>
                    <li class="before"></li>
                    <li class="after"></li>
                </ul>
                <p class="dov1">Правильная атмосфера</p>
                <p class="dov2">100% попадание</p>
                <p class="dov3">Закрывают от солнца</p>
            </div>
            <div class="first-slider-wrap" data-slide>
                <div class="first-slider-lint">
                    <div class="first-slider-slide"></div>
                    <div class="first-slider-slide"></div>
                    <div class="first-slider-slide"></div>
                    <div class="first-slider-slide"></div>
                </div>
                <a class="strb_l" href="#"></a>
                <a class="strb_r" href="#"></a>
            </div>
        </section>
        <section class="sec3" id="m-sect3">
            <div class="wrap">
                <h2>Ответьте на вопросы и получите <br>скидку 10% на дизайн проект</h2>
                <div class="form_gr">
                    <div class="slid1 calc-step active" data-step="1">
                        <h3>Для чего необходимо подобрать шторы <br>и оформить интерьер?</h3>
                        <a class="var1" href="#">Квартира / Дом
                            <span>1</span>
                        </a>
                        <a class="var2" href="#">Организации
                            <span>2</span>
                        </a>
                        <a class="var3" href="#">Мероприятие
                            <span>3</span>
                        </a>
                    </div>
                    <div class="slid2 calc-step" data-step="2">
                        <h3>Стилистика помещения уже проработана?</h3>
                        <a class="btn" href="#">проработана</a>
                        <a class="btn" href="#">требует разработки</a>
                        <span class="back_k">Назад</span>
                    </div>
                    <div class="slid3 calc-step" data-step="3">
                        <h3>Что скажете по срокам?</h3>
                        <a class="btn" href="#">Время есть</a>
                        <a class="btn" href="#">Сроки горят</a>
                        <span class="back_k">Назад</span>
                    </div>
                    <div class="slid4 calc-step" data-step="4">
                        <h3>Заполните форму и узнайте ориентировочную стоимость <br>разработки штор и оформления интерьера для Вас!</h3>
                        <form action="ajax/mail.php" method="POST">
                            <input name="name" type="text" placeholder="Введите имя">
                            <input name="phone" type="text" placeholder="Введите телефон">
                            <input name="frm" type="hidden" value="Форма-калькулятор">
                            <input name="event" type="hidden" value="calc">
                            <input name="step1" type="hidden">
                            <input name="step2" type="hidden">
                            <input name="step3" type="hidden">
                            <button type="submit" value="Получить сейчас">Получить сейчас</button>
                        </form>
                        <span class="back_k">Назад</span>
                        <span>Все ваши данные полностью конфидицельны</span>
                    </div>
                    <div class="form_line" data-step="1"></div>
                </div>
            </div>
        </section>
        <section class="sec4" id="m-sect4">
            <div class="wrap">
                <h2>Проблемы, которых Вы избежите, <br>работая с нами</h2>
                <div class="prob_gr">
                    <p>Затянутые сроки <br>
                        <span>Зачастую услугу по <br>разработке штор <br>предлагают посредники, <br>без своего производства</span>
                    </p>
                    <p>Не совпадает <br>с дизайном <br>
                        <span>Дизайнер фрилансер <br>не работает в штате и <br>не советуется с отделом <br>производства</span>
                    </p>
                    <p>Низкое качество <br>
                        <span>Текстильный брак, <br>поехавший рисунок, <br>несоблюдение габаритов</span>
                    </p>
                    <p>Прогиб карниза <br>
                        <span>Из за несоблюдения <br>габаритов или ошибки при <br>расчете карниз может <br>прогибаться или выпадать</span>
                    </p>
                </div>
            </div>
        </section>
        <section class="sec5" id="m-sect5">
            <div class="wrap">
                <h2>О нашей компании <br>в цифрах</h2>
                <div class="cifri">
                    <div>
                        <h4>15000</h4>
                        <p>тканей на выбор</p>
                    </div>
                    <div>
                        <h4>37</h4>
                        <p>оформленных <br>гос. объектов</p>
                    </div>
                    <div>
                        <h4>27</h4>
                        <p>сотрудников на <br>
                            <span>собственном</span> <br>
                            <span>производстве</span>
                        </p>
                    </div>
                    <div>
                        <h4>2</h4>
                        <p>собственных <br>салона</p>
                    </div>
                    <div>
                        <h4>
                            <span>Более</span> <br>5000</h4>
                        <p>клиентов</p>
                    </div>
                    <div>
                        <h4>14 <br>лет</h4>
                        <p>на рынке</p>
                    </div>
                </div>
            </div>
            <div class="form_gr">
                <h3>Получите консультацию от дизайнера с <br>опытом 10 лет прямо сейчас</h3>
                <form action="ajax/mail.php" method="POST">
                    <input name="name" type="text" placeholder="Введите имя">
                    <input name="phone" type="text" placeholder="Введите телефон">
                    <input name="frm" type="hidden" value="Получите консультацию">
                    <input name="event" type="hidden" value="consult">
                    <button type="submit" value="Получить сейчас">Получить сейчас</button>
                </form>
                <span>Все ваши данные полностью конфидицельны</span>
            </div>
        </section>
        <section class="sec6" id="m-sect6">
            <div class="wrap">
                <h2>Фотографии нашего <br>производства и бутиков</h2>
                <div class="slid1_gr">
                    <div class="slid1_wrap">
                        <div class="slid1_slide">
                            <div class="left">
                                <h4>Офис1 на первом этаже <br>в новом здании <br>по ул. Ленина</h4>
                                <p>Юных модниц и модников ждет <br>концерт рэпера L’One и группы <br>Mana Island, а также диджей-сэт <br>S-Brother-S. </p>
                            </div>
                            <div class="right">
                                <ul class="bxslider1" id="small_bx_1">
                                    <li>
                                        <img class="lazy" src="img/slider/slid1_b.jpg" alt> </li>
                                    <li>
                                        <img class="lazy" src="img/slider/slid1_b.jpg" alt> </li>
                                    <li>
                                        <img class="lazy" src="img/slider/slid1_b.jpg" alt> </li>
                                    <li>
                                        <img class="lazy" src="img/slider/slid1_b.jpg" alt> </li>
                                </ul>
                                <div class="bx-pager1">
                                    <div class="pager-1-w">
                                        <div class="pager-1" id="smbx1p">
                                            <a class="sl_hov" data-slide-index="0" href="#">
                                                <span class="hov_sl"></span>
                                                <img class="lazy" src="img/slider/slid1_b.jpg" alt> </a>
                                            <a class="sl_hov" data-slide-index="1" href="#">
                                                <span class="hov_sl"></span>
                                                <img class="lazy" src="img/slider/slid1_b.jpg" alt> </a>
                                            <a class="sl_hov" data-slide-index="2" href="#">
                                                <span class="hov_sl"></span>
                                                <img class="lazy" src="img/slider/slid1_b.jpg" alt> </a>
                                            <a class="sl_hov" data-slide-index="3" href="#">
                                                <span class="hov_sl"></span>
                                                <img class="lazy" src="img/slider/slid1_b.jpg" alt> </a>
                                        </div>
                                    </div>
                                    <span class="strm_l" id="slbx1l"></span>
                                    <span class="strm_r" id="slbx1r"></span>
                                </div>
                            </div>
                        </div>
                        <div class="slid1_slide">
                            <div class="left">
                                <h4>Офис2 на первом этаже <br>в новом здании <br>по ул. Ленина</h4>
                                <p>Юных модниц и модников ждет <br>концерт рэпера L’One и группы <br>Mana Island, а также диджей-сэт <br>S-Brother-S. </p>
                            </div>
                            <div class="right">
                                <ul class="bxslider1" id="small_bx_2">
                                    <li>
                                        <img class="lazy" src="img/slider/slid1_b.jpg" alt> </li>
                                    <li>
                                        <img class="lazy" src="img/slider/slid1_b.jpg" alt> </li>
                                    <li>
                                        <img class="lazy" src="img/slider/slid1_b.jpg" alt> </li>
                                    <li>
                                        <img class="lazy" src="img/slider/slid1_b.jpg" alt> </li>
                                </ul>
                                <div class="bx-pager1">
                                    <div class="pager-1-w">
                                        <div class="pager-1" id="smbx2p">
                                            <a class="sl_hov" data-slide-index="0" href="#">
                                                <span class="hov_sl"></span>
                                                <img class="lazy" src="img/slider/slid1_b.jpg" alt> </a>
                                            <a class="sl_hov" data-slide-index="1" href="#">
                                                <span class="hov_sl"></span>
                                                <img class="lazy" src="img/slider/slid1_b.jpg" alt> </a>
                                            <a class="sl_hov" data-slide-index="2" href="#">
                                                <span class="hov_sl"></span>
                                                <img class="lazy" src="img/slider/slid1_b.jpg" alt> </a>
                                            <a class="sl_hov" data-slide-index="3" href="#">
                                                <span class="hov_sl"></span>
                                                <img class="lazy" src="img/slider/slid1_b.jpg" alt> </a>
                                        </div>
                                    </div>
                                    <span class="strm_l" id="slbx2l"></span>
                                    <span class="strm_r" id="slbx2r"></span>
                                </div>
                            </div>
                        </div>
                        <div class="slid1_slide">
                            <div class="left">
                                <h4>Офис2 на первом этаже <br>в новом здании <br>по ул. Ленина</h4>
                                <p>Юных модниц и модников ждет <br>концерт рэпера L’One и группы <br>Mana Island, а также диджей-сэт <br>S-Brother-S. </p>
                            </div>
                            <div class="right">
                                <ul class="bxslider1" id="small_bx_3">
                                    <li>
                                        <img class="lazy" src="img/slider/slid1_b.jpg" alt> </li>
                                    <li>
                                        <img class="lazy" src="img/slider/slid1_b.jpg" alt> </li>
                                    <li>
                                        <img class="lazy" src="img/slider/slid1_b.jpg" alt> </li>
                                    <li>
                                        <img class="lazy" src="img/slider/slid1_b.jpg" alt> </li>
                                </ul>
                                <div class="bx-pager1">
                                    <div class="pager-1-w">
                                        <div class="pager-1" id="smbx3p">
                                            <a class="sl_hov" data-slide-index="0" href="#">
                                                <span class="hov_sl"></span>
                                                <img class="lazy" src="img/slider/slid1_b.jpg" alt> </a>
                                            <a class="sl_hov" data-slide-index="1" href="#">
                                                <span class="hov_sl"></span>
                                                <img class="lazy" src="img/slider/slid1_b.jpg" alt> </a>
                                            <a class="sl_hov" data-slide-index="2" href="#">
                                                <span class="hov_sl"></span>
                                                <img class="lazy" src="img/slider/slid1_b.jpg" alt> </a>
                                            <a class="sl_hov" data-slide-index="3" href="#">
                                                <span class="hov_sl"></span>
                                                <img class="lazy" src="img/slider/slid1_b.jpg" alt> </a>
                                        </div>
                                    </div>
                                    <span class="strm_l" id="slbx3l"></span>
                                    <span class="strm_r" id="slbx3r"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="controls">
                        <div class="str_gr">
                            <span class="str_l" id="bbxl"></span>
                            <span class="str_r" id="bbxr"></span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="sec7" id="m-sect7">
            <div class="wrap">
                <h2>Посмотрите истории наших <br>заказчиков</h2>
                <div class="bxslider2">
                    <div class="bx-slider-2-w" id="bx_otz">
                        <div class="bx-slider-2-slide">
                            <img class="lazy" src="img/slider/slid1_b.jpg" alt>
                            <div class="div">
                                <h4>Смерч1 <br>Василий Генадьевич</h4>
                                <p>Планировка квартиры площадью 95 кв.м. в <br>многоэтажном доме была незначительно <br>изменена по желанию заказчика: мы <br>расширили гостиную, объединив ее с <br>лоджией, чтобы создать обеденную зону <br>возле окна. На все работы по <br>перепланировке было получено разрешение <br>и ушло около месяца. В качестве <br>напольного покрытия для гостиной был <br>выбран бельгийский ламинат, а для <br>детской, рабочего кабинета и спальни – <br>дубовая паркетная доска.</p>
                            </div>
                        </div>
                        <div class="bx-slider-2-slide">
                            <img class="lazy" src="img/slider/slid1_b.jpg" alt>
                            <div class="div">
                                <h4>Смерч2 <br>Василий Генадьевич</h4>
                                <p>Планировка квартиры площадью 95 кв.м. в <br>многоэтажном доме была незначительно <br>изменена по желанию заказчика: мы <br>расширили гостиную, объединив ее с <br>лоджией, чтобы создать обеденную зону <br>возле окна. На все работы по <br>перепланировке было получено разрешение <br>и ушло около месяца. В качестве <br>напольного покрытия для гостиной был <br>выбран бельгийский ламинат, а для <br>детской, рабочего кабинета и спальни – <br>дубовая паркетная доска.</p>
                            </div>
                        </div>
                        <div class="bx-slider-2-slide">
                            <img class="lazy" src="img/slider/slid1_b.jpg" alt>
                            <div class="div">
                                <h4>Смерч3 <br>Василий Генадьевич</h4>
                                <p>Планировка квартиры площадью 95 кв.м. в <br>многоэтажном доме была незначительно <br>изменена по желанию заказчика: мы <br>расширили гостиную, объединив ее с <br>лоджией, чтобы создать обеденную зону <br>возле окна. На все работы по <br>перепланировке было получено разрешение <br>и ушло около месяца. В качестве <br>напольного покрытия для гостиной был <br>выбран бельгийский ламинат, а для <br>детской, рабочего кабинета и спальни – <br>дубовая паркетная доска.</p>
                            </div>
                        </div>
                    </div>
                    <span class="str_l" id="bxol"></span>
                    <span class="str_r" id="bxor"></span>
                </div>
            </div>
        </section>
        <section class="sec8" id="m-sect8">
            <h2>Контактная <br>информация</h2>
            <!--div class="point"> <h4>Наш офис находится по адресу</h4> <p>Москва, ул. Льва Толстого, 16<br>mail@mail.ru</p></div-->
            <div class="form_gr">
                <h4>Остались вопросы? <br>Пишите</h4>
                <form action="ajax/mail.php" method="POST">
                    <input name="name" type="text" placeholder="Введите имя">
                    <input name="phone" type="text" placeholder="Введите телефон">
                    <input name="frm" type="hidden" value="Остались вопросы">
                    <input name="event" type="hidden" value="question">
                    <textarea name="mess" placeholder="Введите вопрос"></textarea>
                    <button type="submit" value="Отправить">Отправить</button>
                </form>
                <div>
                    <span>8 800 000 99 44</span>
                    <a class="btn zz-btn" href="#">заказать звонок</a>
                </div>
            </div>
            <div class="map" id="map"></div>
        </section>
        <footer>
            <div class="wrap">
                <span class="log_min">© 2016 <br>Магия декора</span>
                <a class="polit" href="#">Политика конфиденциальности</a>
                <p>Следите за нами <br>в соц. сетях:</p>
                <a class="ins" href="https://www.instagram.com/salon__shtor/" target="_blank"></a>
                <a class="vk" href="http://vk.com/club64331670" target="_blank"></a>
                <a class="gulf" href="http://gulfstream.bz/" target="_blank">Разработка сайта:</a>
            </div>
        </footer>
        <div class="menu-btn"></div>
        <div class="menu">
            <a class="menu-a" href="#m-sect1">Главная</a>
            <a class="menu-a" href="#m-sect3">Стоимость</a>
            <a class="menu-a" href="#m-sect4">Без проблем</a>
            <a class="menu-a" href="#m-sect5">О компании</a>
            <a class="menu-a" href="#m-sect6">Фото бутиков</a>
            <a class="menu-a" href="#m-sect7">Отзывы</a>
            <a class="menu-a" href="#m-sect8">Контакты</a>
        </div>
        <div id="hidden-box">
            <div class="popap" id="zz_pop">
                <a class="close" href="#"></a>
                <div class="form_gr">
                    <h3>Оставьте свои <br>контактные данные <br>и мы вам перезвоним</h3>
                    <form action="ajax/mail.php" method="POST">
                        <input name="name" type="text" placeholder="Введите имя">
                        <input name="phone" type="text" placeholder="Введите телефон">
                        <input name="frm" type="hidden" value="Заказать звонок">
                        <input name="event" type="hidden" value="callback">
                        <button type="submit" value="Заказать звонок">Заказать звонок</button>
                    </form>
                </div>
            </div>
            <div class="popap conf" id="conf_pop">
                <a class="close" href="#"></a>
                <div class="form_gr">
                    <h3>Политика конфиденциальности</h3>
                    <p>Наша компания уважительно относится к правам клиента. Соблюдается строгая конфиденциальность при оформлении заказа. Сведения надёжно сохраняются и защищены от передачи.</p>
                    <p>Согласием на обработку данных клиента исключительно с целью оказания услуг является размещение заказа на сайте. К персональным данным относится личная информация о клиенте: домашний адрес; имя, фамилия, отчество; сведения о рождении; имущественное, семейное положение; личные контакты (телефон, электронная почта) и прочие сведения, которые перечислены в Законе РФ № 152-ФЗ «О персональных данных» от 27 июля 2006 г.</p>
                    <p>Клиент вправе отказаться от обработки персональных данных. Нами в данном случае гарантируется удаление с сайта всех персональных данных в трёхдневный срок в рабочее время. Подобный отказ клиент может оформить простым электронным письмом на адрес, указанный на странице нашего сайта.</p>
                </div>
            </div>
            <div class="popap okgo" id="okgo">
                <a class="close" href="#"></a>
                <div class="form_gr">
                    <h3>Спасибо за заявку, наш менеджер свяжется с Вами в ближайшее время</h3>
                </div>
            </div>
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.16/webfont.js"></script>
        <script src="js/init.js"></script>
        <?php include('../track/body.php'); ?>
    </body>
</html>